<?php

namespace App\Http\Middleware;

use Closure;

class Is_login
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $request->headers->set('Accept', 'application/json');
        if (auth('api')->user())
            return $next($request);
        else
            return response()->json(['success' => false, 'message' => translate('error no user')], 404);
    }
}
